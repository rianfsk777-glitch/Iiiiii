package com.pooltrajectoryai

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat

private val Bg = Color(0xFF101A17)
private val CardBg = Color(0xFF1B2924)
private val Mint = Color(0xFF36D399)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MainScreen() }
    }
}

@Composable
private fun MainScreen() {
    val activity = androidx.compose.ui.platform.LocalContext.current as Activity
    var status by remember { mutableStateOf("Pronto para iniciar.") }

    val projectionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val service = Intent(activity, CaptureOverlayService::class.java).apply {
                action = CaptureOverlayService.ACTION_START
                putExtra(CaptureOverlayService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(CaptureOverlayService.EXTRA_RESULT_DATA, result.data)
            }
            ContextCompat.startForegroundService(activity, service)
            status = "Captura autorizada. Serviço iniciado."
        } else {
            status = "A captura de tela não foi autorizada."
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = CardBg, primary = Mint,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Column(
            Modifier.fillMaxSize().background(Bg).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("POOL TRAJECTORY AI", style = MaterialTheme.typography.headlineSmall,
                color = Color.White)
            Text("Versão 0.2.0 • Captura e janela flutuante", color = Mint)
            Card(colors = CardDefaults.cardColors(containerColor = CardBg),
                shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Modo contínuo", color = Color.White)
                    Text("O Android pedirá autorização para compartilhar a tela. Uma janela flutuante poderá ficar sobre o jogo.",
                        color = Color.LightGray)
                    Button(
                        onClick = {
                            if (!Settings.canDrawOverlays(activity)) {
                                val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                    Uri.parse("package:${activity.packageName}"))
                                activity.startActivity(intent)
                                status = "Ative 'Exibir sobre outros apps' e volte ao aplicativo."
                            } else {
                                val manager = activity.getSystemService(MediaProjectionManager::class.java)
                                projectionLauncher.launch(manager.createScreenCaptureIntent())
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Ativar captura e sobreposição") }
                    OutlinedButton(
                        onClick = {
                            activity.stopService(Intent(activity, CaptureOverlayService::class.java))
                            status = "Serviço parado."
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Parar") }
                }
            }
            Card(colors = CardDefaults.cardColors(containerColor = CardBg),
                shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Estado", color = Mint)
                    Text(status, color = Color.White)
                }
            }
            Text("Nota: esta versão prepara a captura e a sobreposição. O detector automático de bolas ainda precisa ser integrado antes de exibir previsões reais.",
                color = Color(0xFFA8B8B0), style = MaterialTheme.typography.bodySmall)
        }
    }
}
