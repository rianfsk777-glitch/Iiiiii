package com.pooltrajectoryai

import kotlin.math.*

/**
 * Núcleo inicial de simulação 2D.
 * Coordenadas normalizadas em relação à área útil da mesa.
 * Não prevê uma jogada real até receber posições detectadas e calibração da mesa.
 */
data class Vec2(val x: Double, val y: Double) {
    operator fun plus(o: Vec2) = Vec2(x + o.x, y + o.y)
    operator fun minus(o: Vec2) = Vec2(x - o.x, y - o.y)
    operator fun times(k: Double) = Vec2(x * k, y * k)
    fun dot(o: Vec2) = x * o.x + y * o.y
    fun length() = sqrt(x * x + y * y)
    fun normalized(): Vec2 {
        val n = length()
        return if (n < 1e-9) Vec2(0.0, 0.0) else this * (1.0 / n)
    }
}

data class BallState(val center: Vec2, val velocity: Vec2, val radius: Double)
data class Segment(val from: Vec2, val to: Vec2)

/** Gera uma linha reta até a primeira colisão circular ou até o limite da mesa. */
object PhysicsSimulator {
    fun cuePath(
        cue: BallState,
        direction: Vec2,
        tableMin: Vec2 = Vec2(0.0, 0.0),
        tableMax: Vec2 = Vec2(1.0, 1.0),
        maxDistance: Double = 2.0,
        obstacles: List<BallState> = emptyList()
    ): Segment {
        val d = direction.normalized()
        if (d.length() == 0.0) return Segment(cue.center, cue.center)

        var best = maxDistance
        val r = cue.radius
        if (d.x > 0) best = min(best, (tableMax.x - r - cue.center.x) / d.x)
        if (d.x < 0) best = min(best, (tableMin.x + r - cue.center.x) / d.x)
        if (d.y > 0) best = min(best, (tableMax.y - r - cue.center.y) / d.y)
        if (d.y < 0) best = min(best, (tableMin.y + r - cue.center.y) / d.y)

        for (ball in obstacles) {
            val rel = ball.center - cue.center
            val along = rel.dot(d)
            if (along <= 0) continue
            val perpendicular2 = rel.dot(rel) - along * along
            val combined = cue.radius + ball.radius
            val discriminant = combined * combined - perpendicular2
            if (discriminant >= 0) {
                val hit = along - sqrt(discriminant)
                if (hit > 0) best = min(best, hit)
            }
        }
        val end = cue.center + d * best.coerceAtLeast(0.0)
        return Segment(cue.center, end)
    }

    /** Aproxima desaceleração por atrito em passos discretos. */
    fun advance(ball: BallState, friction: Double, dt: Double): BallState {
        val speed = ball.velocity.length()
        if (speed < 1e-4) return ball.copy(velocity = Vec2(0.0, 0.0))
        val nextSpeed = (speed - friction * dt).coerceAtLeast(0.0)
        val nextVelocity = ball.velocity.normalized() * nextSpeed
        val averageVelocity = (ball.velocity + nextVelocity) * 0.5
        return BallState(ball.center + averageVelocity * dt, nextVelocity, ball.radius)
    }
}
