# Pool Trajectory AI — Android 0.2.0 starter

## Implemented in this source revision
- Android foreground service declaration for MediaProjection capture
- User-consented screen-capture flow
- Android overlay permission flow and floating status panel
- Initial 2D physics math for a cue-ball ray, obstacle collision distance, and friction step
- GitHub Actions workflow to compile a debug APK remotely

## Not yet implemented
- Automatic detection of the pool table, pockets, and balls from captured frames
- Mapping detected coordinates into a calibrated table coordinate system
- Rendering predicted trajectory segments in the overlay
- Accurate spin, throw, cushion response, and collision calibration

The floating panel intentionally does not draw fabricated trajectory lines. The next milestone is the computer-vision detector, then connecting its output to PhysicsSimulator and a transparent overlay canvas.

## Build an APK using only a phone
1. Create a GitHub account or sign in in your phone browser.
2. Create a new repository named `PoolTrajectoryAI`.
3. Upload the contents of this project (not the ZIP file itself; extract it first) to the repository root.
4. Open the repository's **Actions** tab and enable workflows if GitHub asks.
5. Run **Build Android APK** using **Run workflow**.
6. When it finishes, open the run, scroll to **Artifacts**, and download `PoolTrajectoryAI-debug-apk`.
7. Extract the artifact ZIP and install `app-debug.apk`. Android may ask permission to install from that browser/files app.

## Android permissions
The app asks the user to enable "Display over other apps" and to approve Android's screen-capture prompt. Capture is user-visible and can be stopped by stopping the service/app.
